﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace DSBanBiDa
{
    public partial class FormBanBida : Form
    {
        public FormBanBida()
        {
            InitializeComponent();
        }

        private void FormBanBida_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DataSet1.BanBida' table. You can move, or remove it, as needed.
            this.BanBidaTableAdapter.Fill(this.DataSet1.BanBida);

            this.RPBanBida.RefreshReport();
        }
    }
}
