﻿namespace DSBanBiDa
{
    partial class FormBanBida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.RPBanBida = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataSet1 = new DSBanBiDa.DataSet1();
            this.BanBidaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.BanBidaTableAdapter = new DSBanBiDa.DataSet1TableAdapters.BanBidaTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BanBidaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // RPBanBida
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.BanBidaBindingSource;
            this.RPBanBida.LocalReport.DataSources.Add(reportDataSource1);
            this.RPBanBida.LocalReport.ReportEmbeddedResource = "DSBanBiDa.ReportBanBida.rdlc";
            this.RPBanBida.Location = new System.Drawing.Point(12, 12);
            this.RPBanBida.Name = "RPBanBida";
            this.RPBanBida.Size = new System.Drawing.Size(655, 425);
            this.RPBanBida.TabIndex = 0;
            // 
            // DataSet1
            // 
            this.DataSet1.DataSetName = "DataSet1";
            this.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // BanBidaBindingSource
            // 
            this.BanBidaBindingSource.DataMember = "BanBida";
            this.BanBidaBindingSource.DataSource = this.DataSet1;
            // 
            // BanBidaTableAdapter
            // 
            this.BanBidaTableAdapter.ClearBeforeFill = true;
            // 
            // FormBanBida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 449);
            this.Controls.Add(this.RPBanBida);
            this.Name = "FormBanBida";
            this.Text = "FormBanBida";
            this.Load += new System.EventHandler(this.FormBanBida_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BanBidaBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer RPBanBida;
        private System.Windows.Forms.BindingSource BanBidaBindingSource;
        private DataSet1 DataSet1;
        private DataSet1TableAdapters.BanBidaTableAdapter BanBidaTableAdapter;
    }
}