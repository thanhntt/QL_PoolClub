﻿namespace ReportDSNhanVien {
    
    
    public partial class DataSet1 {
        partial class NhanVienDataTable
        {
        }
    }
}
