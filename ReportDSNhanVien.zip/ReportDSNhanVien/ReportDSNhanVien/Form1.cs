﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace ReportDSNhanVien
{
    public partial class Form1 : Form
    {
        SqlConnection cn;
        string cnStr;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cn = new SqlConnection();
            try
            {
                cnStr = ConfigurationManager.ConnectionStrings["cnStr"].ConnectionString;
                cn.ConnectionString = cnStr;
                string sql = @"Select * from NhanVien";
                dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                da.Fill(dt);
                NhanVienBindingSource.DataSource = dt;
                this.reportViewer1.RefreshReport();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.Close();
            }
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
